package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock

object Commands {
    private val alias = mapOf("pabji" to "pubg", "pubji" to "pubg", "telegram" to "telegram", "yutub" to "youtube")

    fun run(c: Context, raw: String) {
        val t = raw.lowercase().replace("’", "'").replace("ʻ", "'").replace("‘", "'")
        when {
            t.contains("budilnik") || t.contains("uyg'ot") -> alarm(c, t)
            t.contains("och") -> openApp(c, t)
        }
    }

    private fun alarm(c: Context, t: String) {
        var h: Int; var m = 0
        val full = Regex("(\\d{1,2})\\D+(\\d{2})").find(t)
        if (full != null) { h = full.groupValues[1].toInt(); m = full.groupValues[2].toInt() }
        else h = Regex("(\\d{1,2})").find(t)?.groupValues?.get(1)?.toInt() ?: return
        if ((t.contains("kech") || t.contains("tush")) && h < 12) h += 12
        c.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, h); putExtra(AlarmClock.EXTRA_MINUTES, m)
            putExtra(AlarmClock.EXTRA_MESSAGE, "Xoqon"); putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }

    private fun openApp(c: Context, t: String) {
        var name = t.replace(Regex("\\b(ochib ber|och|ni|ilovasini|ilova)\\b"), "").trim()
        name = alias[name] ?: name
        if (name.isEmpty()) return
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull {
            val l = it.loadLabel(pm).toString().lowercase()
            l.contains(name) || name.contains(l)
        } ?: return
        pm.getLaunchIntentForPackage(hit.activityInfo.packageName)?.let {
            it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(it)
        }
    }
}
