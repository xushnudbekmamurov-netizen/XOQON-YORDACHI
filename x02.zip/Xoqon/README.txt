1) https://alphacephei.com/vosk/models saytidan "vosk-model-small-uz" (o'zbek, ~50 MB) ni yuklab oling va zip'ni oching.
2) Ichidagi papkaning ICHIDAGI fayllarni (am, conf, graph, ivector ...) app/src/main/assets/model-uz/ ichiga ko'chiring.
   (u yerdagi "uuid" faylni o'chirmang.)
3) Android Studio'da Xoqon papkasini oching -> Build > Build APK(s).
4) Telefonga o'rnating, ilovada 1-4 tugmalarni ketma-ket bosing.
Buyruqlar: "Xoqon" ... "soat 7:30 ga budilnik qo'y", "Telegram och".
Eshitilgan matn ekranda ko'rinadi; "Xoqon"ni boshqacha eshitsa, WakeService.kt dagi wake ro'yxatiga qo'shing.
