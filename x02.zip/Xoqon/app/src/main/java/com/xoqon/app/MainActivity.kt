package com.xoqon.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        l.addView(TextView(this).apply { text = "Xoqon yordamchi"; textSize = 24f })
        l.addView(btn("1. Ruxsatlar (mikrofon, bildirishnoma)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS), 1)
        })
        l.addView(btn("2. Boshqa ilovalar ustida ko'rsatish") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        l.addView(btn("3. Batareya cheklovini o'chirish") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        l.addView(btn("4. Ishga tushirish") {
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
        })
        l.addView(btn("To'xtatish") { stopService(Intent(this, WakeService::class.java)) })
        setContentView(l)
    }
}
