package com.xoqon.app

import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.provider.ContactsContract
import android.telephony.SmsManager
import android.widget.Toast

object Sms {
    private val alias = mapOf(
        "onam" to listOf("onam", "ona", "oyi", "mama", "онам", "она"),
        "dadam" to listOf("dadam", "ota", "dada", "papa", "дадам", "ота"),
        "akam" to listOf("akam", "aka", "ака"),
        "opam" to listOf("opam", "opa", "singlim", "опа")
    )

    fun tryHandle(c: Context, t: String): Boolean {
        if (!t.contains(" deb ")) return false
        val left = t.substringBefore(" deb ").trim()
        val right = t.substringAfter(" deb ")
        val isSms = listOf("xabar", "habar", "sms").any { right.contains(it) } && listOf("yoz", "yubor").any { right.contains(it) }
        if (!isSms) return false
        val words = left.split(" ").filter { it.isNotBlank() }
        if (words.size < 2) { toast(c, "Xabar matni aytilmadi"); tone(false); return true }
        val w = words[0]
        val names = (if (w.length > 3 && (w.endsWith("ga") || w.endsWith("ka") || w.endsWith("qa"))) listOf(w.dropLast(2), w) else listOf(w))
        val body = words.drop(1).joinToString(" ").replaceFirstChar { it.uppercase() }
        var number: String? = null
        for (n in names) { number = find(c, n); if (number != null) break }
        if (number == null) { toast(c, "Kontakt topilmadi: ${names[0]}"); tone(false); return true }
        try {
            val m = mgr(c)
            m.sendMultipartTextMessage(number, null, m.divideMessage(body), null, null)
            tone(true)
            toast(c, "Yuborildi ($number): $body")
        } catch (e: Exception) {
            tone(false)
            toast(c, "SMS xatosi: ${e.message}")
        }
        return true
    }

    private fun find(c: Context, name: String): String? {
        for (tok in (alias[name] ?: listOf(name))) {
            for (v in listOf(tok, tok.replaceFirstChar { it.uppercase() })) {
                try {
                    c.contentResolver.query(
                        ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                        arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                        ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
                        arrayOf("%" + v + "%"), null
                    )?.use { if (it.moveToFirst()) return it.getString(0) }
                } catch (e: Exception) { return null }
            }
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun mgr(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun tone(ok: Boolean) {
        ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK)
    }

    private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()
}
