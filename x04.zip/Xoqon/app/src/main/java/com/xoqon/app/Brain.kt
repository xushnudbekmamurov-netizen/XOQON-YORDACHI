package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private const val MODEL = "claude-haiku-5-5"
    private val main = Handler(Looper.getMainLooper())

    fun key(c: Context): String = c.getSharedPreferences("x", Context.MODE_PRIVATE).getString("apikey", "")?.trim() ?: ""
    fun enabled(c: Context) = key(c).isNotEmpty()

    fun handle(c: Context, text: String) {
        val k = key(c)
        if (k.isEmpty()) { Commands.run(c, text); return }
        val labels = appLabels(c)
        Thread {
            try {
                val json = ask(k, text, labels)
                main.post { dispatch(c, json) }
            } catch (e: Exception) {
                main.post {
                    Toast.makeText(c, "AI xatosi: " + e.message, Toast.LENGTH_LONG).show()
                    Commands.run(c, text)
                }
            }
        }.start()
    }

    private fun appLabels(c: Context): List<String> {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().take(250)
    }

    private fun ask(key: String, text: String, labels: List<String>): JSONObject {
        val sys = "You are Jarvis, a voice assistant on an Android phone. The user speaks Uzbek; speech recognition output is noisy " +
            "(Latin or Cyrillic letters, wrong spellings, foreign app names written phonetically, e.g. 'pabji' means PUBG). " +
            "Infer what the user meant and answer with ONE JSON object only, no other text. Allowed forms: " +
            "{\"action\":\"open_app\",\"app\":\"<exact label from the installed list>\"} ; " +
            "{\"action\":\"alarm\",\"hour\":0-23,\"minute\":0-59} ; " +
            "{\"action\":\"sms\",\"contact\":\"<contact name in Latin, e.g. onam>\",\"text\":\"<message to send>\"} ; " +
            "{\"action\":\"music\",\"cmd\":\"play|pause|next|prev\"} ; " +
            "{\"action\":\"youtube\",\"query\":\"<search>\"} ; " +
            "{\"action\":\"chat\",\"text\":\"<short Uzbek answer, max 2 sentences>\"} for questions or small talk ; " +
            "{\"action\":\"unknown\"} if unclear. " +
            "For open_app the app value must be copied exactly from this installed list: " + labels.joinToString("; ")
        val body = JSONObject().put("model", MODEL).put("max_tokens", 300).put("system", sys)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
        val conn = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 8000; conn.readTimeout = 20000; conn.doOutput = true
        conn.setRequestProperty("x-api-key", key)
        conn.setRequestProperty("anthropic-version", "2023-06-01")
        conn.setRequestProperty("content-type", "application/json")
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val st = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = st?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP " + code + " " + resp.take(120))
        val out = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }

    private fun dispatch(c: Context, a: JSONObject) {
        Toast.makeText(c, "Jarvis: " + a.toString().take(120), Toast.LENGTH_SHORT).show()
        when (a.optString("action")) {
            "open_app" -> openLabel(c, a.optString("app"))
            "alarm" -> Commands.run(c, "budilnik " + a.optInt("hour") + ":" + a.optInt("minute").toString().padStart(2, '0'))
            "sms" -> Sms.sendTo(c, a.optString("contact"), a.optString("text"))
            "music" -> Music.tryHandle(c, when (a.optString("cmd")) { "pause" -> "to'xtat"; "next" -> "keyingi"; "prev" -> "oldingi"; else -> "musiqa qo'y" })
            "youtube" -> if (!Music.tryHandle(c, "youtube " + a.optString("query"))) Speaker.say("Tushunmadim")
            "chat" -> {
                val s = a.optString("text")
                if (s.isNotBlank()) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); Speaker.say(s) }
            }
            else -> Speaker.say("Tushunmadim")
        }
    }

    private fun openLabel(c: Context, label: String) {
        val pm = c.packageManager
        val l = label.lowercase()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == l }
            ?: apps.firstOrNull { l.isNotEmpty() && it.loadLabel(pm).toString().lowercase().contains(l) }
        if (hit == null) { Speaker.say("Topolmadim"); return }
        try {
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            Speaker.say(hit.loadLabel(pm).toString() + " ni ochayapman")
        } catch (e: Exception) { Speaker.say("Ocha olmadim") }
    }
}
