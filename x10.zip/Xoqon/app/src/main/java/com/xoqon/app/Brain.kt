package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private const val CLAUDE = "claude-haiku-5-5"
    private const val GEMINI = "gemini-3.5-flash"
    private const val GEMINI_OLD = "gemini-2.5-flash"
    private const val OPENAI = "gpt-4o-mini"
    private val main = Handler(Looper.getMainLooper())

    fun key(c: Context): String = c.getSharedPreferences("x", Context.MODE_PRIVATE).getString("apikey", "")?.trim() ?: ""
    fun enabled(c: Context) = key(c).isNotEmpty()

    // Kalitni tekshirish: kichik so'rov yuboradi va natijani matn qilib qaytaradi
    fun test(key: String, cb: (String) -> Unit) {
        val kind = when {
            key.startsWith("sk-ant-") -> "Claude"
            key.startsWith("AQ.") || key.startsWith("AIza") -> "Gemini"
            key.startsWith("sk-") -> "ChatGPT"
            else -> ""
        }
        if (kind.isEmpty()) { cb("✗ Kalit turi tanilmadi. Claude: sk-ant-, ChatGPT: sk-, Gemini: AQ. yoki AIza bilan boshlanadi"); return }
        Thread {
            val msg = try {
                val j = ask(key, "salom", listOf())
                "✓ " + kind + " kaliti ishlayapti. Javob: " + j.toString().take(80)
            } catch (e: Exception) { "✗ " + kind + " xatosi: " + (e.message ?: "noma'lum") }
            cb(msg)
        }.start()
    }

    fun handle(c: Context, text: String) {
        val k = key(c)
        if (k.isEmpty()) { Commands.run(c, text); return }
        val labels = appLabels(c)
        Thread {
            try {
                val json = ask(k, text, labels)
                main.post { dispatch(c, json) }
            } catch (e: Exception) {
                main.post {
                    Toast.makeText(c, "AI xatosi: " + e.message, Toast.LENGTH_LONG).show()
                    Commands.run(c, text)
                }
            }
        }.start()
    }

    private fun appLabels(c: Context): List<String> {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().take(250)
    }

    private fun system(labels: List<String>): String =
        "You are Jarvis, a voice assistant on an Android phone. The user speaks Uzbek; speech recognition output is noisy " +
        "(Latin or Cyrillic letters, wrong spellings, foreign app names written phonetically, e.g. 'pabji' means PUBG). " +
        "Infer what the user meant and answer with ONE JSON object only, no other text. Allowed forms: " +
        "{\"action\":\"open_app\",\"app\":\"<exact label from the installed list>\"} ; " +
        "{\"action\":\"alarm\",\"hour\":0-23,\"minute\":0-59} ; " +
        "{\"action\":\"sms\",\"contact\":\"<contact name in Latin, e.g. onam>\",\"text\":\"<message to send>\"} ; " +
        "{\"action\":\"music\",\"cmd\":\"play|pause|next|prev\"} ; " +
        "{\"action\":\"youtube\",\"query\":\"<search>\"} ; " +
        "{\"action\":\"system\",\"cmd\":\"wifi|bluetooth|home|flashlight_on|flashlight_off|volume_up|volume_down\"} for phone controls (home = leave the current app / go to home screen) ; " +
        "{\"action\":\"chat\",\"text\":\"<short Uzbek answer, max 2 sentences>\"} for questions or small talk ; " +
        "{\"action\":\"unknown\"} if unclear. " +
        "For open_app the app value must be copied exactly from this installed list: " + labels.joinToString("; ")

    // Kalit turini boshlanishidan aniqlaydi: sk-ant- (Claude), AIza (Gemini), sk- (ChatGPT)
    private fun ask(key: String, text: String, labels: List<String>): JSONObject {
        val sys = system(labels)
        val out: String = when {
            key.startsWith("sk-ant-") -> {
                val body = JSONObject().put("model", CLAUDE).put("max_tokens", 300).put("system", sys)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
                val r = post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
                JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
            }
            key.startsWith("AQ.") || key.startsWith("AIza") -> gemini(key, sys, text)
            key.startsWith("sk-") -> {
                val body = JSONObject().put("model", OPENAI).put("max_tokens", 300).put("response_format", JSONObject().put("type", "json_object"))
                    .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                        .put(JSONObject().put("role", "user").put("content", text)))
                val r = post("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer " + key), body)
                JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
            else -> throw Exception("Kalit turi tanilmadi (sk-ant-, sk-, AQ., AIza)")
        }
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }

    // Avval klassik usul (tez), bo'lmasa Google'ning yangi Interactions usuli. Xatolar ekranda ko'rinadi.
    private fun gemini(key: String, sys: String, text: String): String {
        val errs = StringBuilder()
        try {
            val body = JSONObject()
                .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))))
                .put("generationConfig", JSONObject().put("maxOutputTokens", 600).put("responseMimeType", "application/json")
                    .put("thinkingConfig", JSONObject().put("thinkingBudget", 0)))
            val r = post("https://generativelanguage.googleapis.com/v1beta/models/" + GEMINI_OLD + ":generateContent", mapOf("x-goog-api-key" to key), body, 15000)
            return JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
        } catch (e: Exception) { errs.append("A: ").append(e.message) }
        try {
            val body = JSONObject().put("model", GEMINI).put("input", sys + "\n\nUser said (transcript): " + text)
            val r = post("https://generativelanguage.googleapis.com/v1beta/interactions", mapOf("x-goog-api-key" to key), body, 30000)
            return geminiText(JSONObject(r))
        } catch (e: Exception) { errs.append(" | B: ").append(e.message) }
        throw Exception(errs.toString())
    }

    // Interactions API javobining ikkala shaklini o'qiydi (outputs yoki steps)
    private fun geminiText(j: JSONObject): String {
        val direct = j.optString("output_text")
        if (direct.isNotEmpty()) return direct
        val outs = j.optJSONArray("outputs")
        if (outs != null) for (i in outs.length() - 1 downTo 0) {
            val t = outs.optJSONObject(i)?.optString("text") ?: ""
            if (t.isNotEmpty()) return t
        }
        val steps = j.optJSONArray("steps")
        if (steps != null) for (i in steps.length() - 1 downTo 0) {
            val content = steps.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (k in 0 until content.length()) {
                val t = content.optJSONObject(k)?.optString("text") ?: ""
                if (t.isNotEmpty()) return t
            }
        }
        throw Exception("Gemini javobi tushunarsiz: " + j.toString().take(120))
    }

    private fun post(url: String, headers: Map<String, String>, body: JSONObject, readMs: Int = 20000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 8000; conn.readTimeout = readMs; conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val st = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = st?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP " + code + " " + resp.take(150))
        return resp
    }

    private fun dispatch(c: Context, a: JSONObject) {
        Toast.makeText(c, "Jarvis: " + a.toString().take(120), Toast.LENGTH_SHORT).show()
        when (a.optString("action")) {
            "open_app" -> openLabel(c, a.optString("app"))
            "alarm" -> Commands.run(c, "budilnik " + a.optInt("hour") + ":" + a.optInt("minute").toString().padStart(2, '0'))
            "sms" -> Sms.sendTo(c, a.optString("contact"), a.optString("text"))
            "music" -> Music.tryHandle(c, when (a.optString("cmd")) { "pause" -> "to'xtat"; "next" -> "keyingi"; "prev" -> "oldingi"; else -> "musiqa qo'y" })
            "system" -> Sys.run(c, a.optString("cmd"))
            "youtube" -> if (!Music.tryHandle(c, "youtube " + a.optString("query"))) Speaker.say("Tushunmadim")
            "chat" -> {
                val s = a.optString("text")
                if (s.isNotBlank()) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); Speaker.say(s) }
            }
            else -> Speaker.say("Tushunmadim")
        }
    }

    private fun openLabel(c: Context, label: String) {
        val pm = c.packageManager
        val l = label.lowercase()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == l }
            ?: apps.firstOrNull { l.isNotEmpty() && it.loadLabel(pm).toString().lowercase().contains(l) }
        if (hit == null) { Speaker.say("Topolmadim"); return }
        try {
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            Speaker.say(hit.loadLabel(pm).toString() + " ni ochayapman")
        } catch (e: Exception) { Speaker.say("Ocha olmadim") }
    }
}
