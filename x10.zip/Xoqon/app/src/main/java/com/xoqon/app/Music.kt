package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.view.KeyEvent
import android.widget.Toast

object Music {
    private val noise = setOf("qo'y", "qoy", "qidir", "top", "och", "ber", "ni", "da", "dan", "bilan", "ilovasida", "ilovada")

    fun tryHandle(c: Context, t: String): Boolean {
        if (t.contains("youtube") || t.contains("yutub")) {
            val q = t.split(" ").filter { w ->
                w.isNotBlank() && !w.startsWith("youtube") && !w.startsWith("yutub") && w !in noise
            }.joinToString(" ")
            if (q.isBlank()) return false
            return youtube(c, q)
        }
        val code = when {
            has(t, "to'xtat", "pauza", "tinch") -> KeyEvent.KEYCODE_MEDIA_PAUSE
            has(t, "keyingi", "next") -> KeyEvent.KEYCODE_MEDIA_NEXT
            has(t, "oldingi", "avvalgi") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            has(t, "musiqa", "qo'shiq", "davom", "play") -> KeyEvent.KEYCODE_MEDIA_PLAY
            else -> return false
        }
        press(c, code)
        Toast.makeText(c, "Musiqa: $t", Toast.LENGTH_SHORT).show()
        return true
    }

    private fun has(t: String, vararg k: String) = k.any { t.contains(it) }

    private fun press(c: Context, code: Int) {
        val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    private fun youtube(c: Context, q: String): Boolean {
        try {
            c.startActivity(Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube")
                .putExtra("query", q).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Toast.makeText(c, "YouTube: $q", Toast.LENGTH_SHORT).show(); Speaker.say("YouTubeda qidiryapman")
        } catch (e: Exception) {
            try {
                c.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
                Toast.makeText(c, "YouTube ochilmadi: ${e2.message}", Toast.LENGTH_LONG).show()
            }
        }
        return true
    }
}
