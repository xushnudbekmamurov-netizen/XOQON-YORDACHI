package com.xoqon.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile var ready = false

    fun init(c: Context) {
        if (tts != null) return
        val ctx = c.applicationContext
        val locales = listOf(Locale("uz", "UZ"), Locale("uz"), Locale("tr", "TR"), Locale("ru", "RU"))
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                for (loc in locales) {
                    if (ready) break
                    val r = tts?.setLanguage(loc) ?: -2
                    if (r >= TextToSpeech.LANG_AVAILABLE) {
                        ready = true
                        main.post { Toast.makeText(ctx, "Ovoz tili: " + loc.language, Toast.LENGTH_LONG).show() }
                    }
                }
            }
        }
    }

    fun say(text: String, onDone: (() -> Unit)? = null) {
        val t = tts
        if (!ready || t == null) { if (onDone != null) main.post { onDone() }; return }
        var done = false
        fun once() { if (!done) { done = true; if (onDone != null) onDone() } }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { once() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { once() } }
        })
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        if (onDone != null) main.postDelayed({ once() }, 4000)
    }

    fun shutdown() { tts?.shutdown(); tts = null; ready = false }
}
