package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import android.provider.Settings
import android.widget.Toast

object Sys {
    fun tryHandle(c: Context, t: String): Boolean {
        val k = t.replace(" ", "").replace("-", "")
        val cmd = when {
            k.contains("wifi") || k.contains("vifi") || k.contains("vayfay") -> "wifi"
            k.contains("bluetooth") || k.contains("blutuz") || k.contains("blyutuz") || k.contains("bluetuz") -> "bluetooth"
            Regex("\\bchiq").containsMatchIn(t) || t.contains("bosh ekran") || t.contains("uyga qayt") -> "home"
            k.contains("chiroq") || k.contains("fonar") || k.contains("flashlight") ->
                if (t.contains("o'chir") || t.contains("ochir")) "flashlight_off" else "flashlight_on"
            k.contains("ovoz") && (t.contains("balandroq") || t.contains("ko'tar") || t.contains("oshir")) -> "volume_up"
            k.contains("ovoz") && (t.contains("pastroq") || t.contains("kamaytir")) -> "volume_down"
            else -> return false
        }
        run(c, cmd)
        return true
    }

    fun run(c: Context, cmd: String) {
        when (cmd) {
            "wifi" -> {
                open(c, if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIFI_SETTINGS))
                Speaker.say("Wi-Fi oynasini ochdim, o'zingiz yoqing")
            }
            "bluetooth" -> {
                open(c, Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
                Speaker.say("Bluetooth sozlamasini ochdim, o'zingiz yoqing")
            }
            "home" -> {
                open(c, Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME))
                Speaker.say("Bosh ekranga chiqdim")
            }
            "flashlight_on" -> torch(c, true)
            "flashlight_off" -> torch(c, false)
            "volume_up" -> vol(c, AudioManager.ADJUST_RAISE)
            "volume_down" -> vol(c, AudioManager.ADJUST_LOWER)
            else -> Speaker.say("Tushunmadim")
        }
    }

    private fun open(c: Context, i: Intent) {
        try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); c.startActivity(i) }
        catch (e: Exception) { Toast.makeText(c, "Ochilmadi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    private fun torch(c: Context, on: Boolean) {
        try {
            val cm = c.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
            if (id == null) { Speaker.say("Chiroq topilmadi"); return }
            cm.setTorchMode(id, on)
            Speaker.say(if (on) "Chiroq yondi" else "Chiroq o'chdi")
        } catch (e: Exception) { Toast.makeText(c, "Chiroq xatosi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    private fun vol(c: Context, dir: Int) {
        try {
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
        } catch (e: Exception) { Toast.makeText(c, "Ovoz xatosi: " + e.message, Toast.LENGTH_LONG).show() }
    }
}
