package com.xoqon.app

import android.Manifest
import android.app.ActivityOptions
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as PhoneKind
import android.service.notification.StatusBarNotification
import android.widget.Toast

object Calls {
    class Hit(val name: String, val number: String, val uri: Uri?)

    fun tryHandle(c: Context, t: String): Boolean {
        val words = t.split(" ").filter { it.isNotBlank() }
        if (t.contains("xabar") && (t.contains("yangi") || t.contains("keldi") || t.contains("oxirgi"))) {
            if (t.contains("o'qi") || t.contains("oqi") || t.contains("eshittir")) readLatest(c) else openLatest(c)
            return true
        }
        val ci = words.indexOfFirst { it.startsWith("telefon") || it.startsWith("qo'ng'iroq") || it.startsWith("qongiroq") || it.startsWith("zvonok") }
        if (ci > 0) { call(c, words.subList(0, ci).joinToString(" ")); return true }
        val ti = words.indexOfFirst { it == "top" || it.startsWith("topib") }
        if (ti > 0 && !t.contains("youtube")) { find(c, words.subList(0, ti).joinToString(" ")); return true }
        return false
    }

    private fun names(raw: String): List<String> {
        val w = Commands.norm(raw).trim().split(" ").first()
        val out = ArrayList<String>()
        if (w.length > 3 && (w.endsWith("ga") || w.endsWith("ka") || w.endsWith("qa") || w.endsWith("ni"))) out.add(w.dropLast(2))
        out.add(w)
        return out
    }

    fun lookup(c: Context, raw: String): Hit? {
        val toks = ArrayList<String>()
        toks.add(Commands.norm(raw).trim())
        for (n in names(raw)) toks.addAll(Sms.alias[n] ?: listOf(n))
        for (tok in toks.distinct()) {
            if (tok.length < 2) continue
            for (v in listOf(tok, tok.replaceFirstChar { it.uppercase() }).distinct()) {
                try {
                    c.contentResolver.query(
                        PhoneKind.CONTENT_URI,
                        arrayOf(PhoneKind.DISPLAY_NAME, PhoneKind.NUMBER, PhoneKind.CONTACT_ID, PhoneKind.LOOKUP_KEY),
                        PhoneKind.DISPLAY_NAME + " LIKE ?", arrayOf("%" + v + "%"), null
                    )?.use {
                        if (it.moveToFirst()) return Hit(it.getString(0) ?: "", it.getString(1) ?: "",
                            ContactsContract.Contacts.getLookupUri(it.getLong(2), it.getString(3)))
                    }
                } catch (e: Exception) { return null }
            }
        }
        return null
    }

    fun call(c: Context, name: String) {
        val h = lookup(c, name)
        if (h == null) { Toast.makeText(c, "Kontakt topilmadi: " + name, Toast.LENGTH_LONG).show(); Speaker.say("Kontakt topilmadi"); return }
        Speaker.say(h.name + " ga qo'ng'iroq qilyapman")
        val granted = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        try {
            c.startActivity(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(h.number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { Toast.makeText(c, "Qo'ng'iroq xatosi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    fun find(c: Context, name: String) {
        val h = lookup(c, name)
        if (h == null) { Toast.makeText(c, "Kontakt topilmadi: " + name, Toast.LENGTH_LONG).show(); Speaker.say("Topolmadim"); return }
        Toast.makeText(c, h.name + ": " + h.number, Toast.LENGTH_LONG).show()
        Speaker.say(h.name + ", raqami " + h.number.filter { it.isDigit() }.toList().joinToString(" "))
        try {
            if (h.uri != null) c.startActivity(Intent(Intent.ACTION_VIEW, h.uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    private fun pick(c: Context): StatusBarNotification? {
        val svc = NotifService.inst ?: return null
        return try {
            val list = svc.activeNotifications.filter { !it.isOngoing && it.packageName != c.packageName && it.notification.contentIntent != null }
            val msgs = list.filter { it.notification.category == Notification.CATEGORY_MESSAGE }
            (if (msgs.isNotEmpty()) msgs else list).maxByOrNull { it.postTime }
        } catch (e: Exception) { null }
    }

    private fun title(n: StatusBarNotification): String = n.notification.extras.getString(Notification.EXTRA_TITLE) ?: n.packageName

    private fun missing(): String = if (NotifService.inst == null) "Bildirishnomalarga ruxsat bering" else "Yangi xabar topilmadi"

    fun openLatest(c: Context) {
        val n = pick(c)
        if (n == null) { Speaker.say(missing()); return }
        try {
            val o = ActivityOptions.makeBasic()
            if (Build.VERSION.SDK_INT >= 34) o.setPendingIntentBackgroundActivityStartMode(ActivityOptions.MODE_BACKGROUND_ACTIVITY_ALLOWED)
            n.notification.contentIntent.send(c, 0, null, null, null, null, o.toBundle())
            Speaker.say(title(n) + " xabarini ochdim")
        } catch (e: Exception) { Toast.makeText(c, "Xabar ochilmadi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    fun readLatest(c: Context) {
        val n = pick(c)
        if (n == null) { Speaker.say(missing()); return }
        val text = n.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        Toast.makeText(c, title(n) + ": " + text, Toast.LENGTH_LONG).show()
        Speaker.say(title(n) + ". " + text)
    }
}
