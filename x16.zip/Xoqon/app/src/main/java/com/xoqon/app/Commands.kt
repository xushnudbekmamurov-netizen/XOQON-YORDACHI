package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.widget.Toast

object Commands {
    val extraWake = listOf("jarvis", "jarvez", "jarviz", "jarvish", "jarves", "jarvi", "jorvis", "jarvus", "ярвис", "жарвис", "жарвиз", "yolg'on", "yolgon", "yolg'an", "xolgon", "xolqon", "qo'qon", "qoqon", "qo'qan", "hoqon", "xoqon")
    private val verbs = listOf("budilnik", "uyg'ot", "ishga tushir", "och", "kir", "musiqa", "qo'shiq", "keyingi", "oldingi", "to'xtat", "pauza", "youtube", "yutub", "wifi", "vifi", "vayfay", "wi-fi", "bluetooth", "blutuz", "blyutuz", "chiq", "chiroq", "fonar", "ovoz", "telefon", "qo'ng'iroq", "xabar", "top", "o'qi")
    private val stop = setOf("och", "ochib", "ber", "kir", "ishga", "tushir", "ilova", "ilovasi", "ilovasini", "ilovasiga", "ga", "ni", "ni", "bor")
    private val alias = mapOf(
        "xabarlar" to listOf("xabarlar", "messages", "message", "sms"),
        "shavarlar" to listOf("xabarlar", "messages", "message", "sms"), "habarlar" to listOf("xabarlar", "messages", "message", "sms"),
        "pabji" to listOf("pubg"), "pubji" to listOf("pubg"), "yutub" to listOf("youtube"),
        "kamera" to listOf("camera", "kamera"), "sozlamalar" to listOf("settings", "sozlamalar"),
        "telefon" to listOf("phone", "telefon"), "galereya" to listOf("gallery", "galereya", "photos"),
        "xrom" to listOf("chrome"), "brauzer" to listOf("chrome", "brave", "browser")
    )
    private val nums = mapOf("bir" to 1, "ikki" to 2, "uch" to 3, "to'rt" to 4, "besh" to 5, "olti" to 6,
        "yetti" to 7, "sakkiz" to 8, "to'qqiz" to 9, "o'n" to 10)

    fun norm(s: String) = s.lowercase().replace("ʻ", "'").replace("’", "'").replace("‘", "'").replace("`", "'")
    fun isCommand(s: String) = norm(s).let { t -> verbs.any { t.contains(it) } }

    // quiet=true: tushunmasa jim qaytadi (false), shunda AI'ga o'tiladi. true = buyruq bajarildi.
    fun run(c: Context, raw: String, quiet: Boolean = false): Boolean {
        val t = norm(raw)
        if (Sms.tryHandle(c, t)) return true
        if (Music.tryHandle(c, t)) return true
        if (Sys.tryHandle(c, t)) return true
        if (Calls.tryHandle(c, t)) return true
        return when {
            t.contains("budilnik") || t.contains("uyg'ot") -> alarm(c, t, quiet)
            t.contains("och") || t.contains("kir") || t.contains("ishga tushir") -> openApp(c, t, quiet)
            else -> {
                if (!quiet) { Toast.makeText(c, "Buyruq tushunilmadi: $t", Toast.LENGTH_LONG).show(); Speaker.say("Tushunmadim") }
                false
            }
        }
    }

    private fun alarm(c: Context, t: String, quiet: Boolean): Boolean {
        var h = -1; var m = 0
        val full = Regex("(\\d{1,2})\\D+(\\d{2})").find(t)
        if (full != null) { h = full.groupValues[1].toInt(); m = full.groupValues[2].toInt() }
        else {
            val one = Regex("(\\d{1,2})").find(t)
            if (one != null) h = one.groupValues[1].toInt()
            else t.split(" ").forEach { w -> nums[w]?.let { h = it } }
        }
        if (h < 0) { if (!quiet) { Toast.makeText(c, "Soat topilmadi: $t", Toast.LENGTH_LONG).show(); Speaker.say("Soatni tushunmadim") }; return false }
        if ((t.contains("kech") || t.contains("tush")) && h < 12) h += 12
        try {
            c.startActivity(Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, h); putExtra(AlarmClock.EXTRA_MINUTES, m)
                putExtra(AlarmClock.EXTRA_MESSAGE, "Xoqon"); putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
            Toast.makeText(c, "Budilnik: $h:${m.toString().padStart(2, '0')}", Toast.LENGTH_LONG).show()
            Speaker.say(if (m == 0) "Budilnik soat $h ga qo'yildi" else "Budilnik soat $h $m ga qo'yildi")
            return true
        } catch (e: Exception) { Toast.makeText(c, "Budilnik xatosi: ${e.message}", Toast.LENGTH_LONG).show(); return false }
    }

    private fun openApp(c: Context, t: String, quiet: Boolean): Boolean {
        val words = t.split(" ").filter { it.isNotBlank() && it !in stop }.map {
            if (it.length > 5 && (it.endsWith("ga") || it.endsWith("ni"))) it.dropLast(2) else it
        }
        val name = words.joinToString(" ")
        if (name.isEmpty()) { if (!quiet) { Toast.makeText(c, "Ilova nomi aytilmadi", Toast.LENGTH_LONG).show(); Speaker.say("Ilova nomini aytmadingiz") }; return false }
        val cands = (alias[name] ?: emptyList()) + name
        val pm = c.packageManager
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { a ->
            val l = norm(a.loadLabel(pm).toString())
            cands.any { (it.length >= 3 && l.contains(it)) || (l.length >= 3 && it.contains(l)) }
        }
        if (hit == null) { if (!quiet) { Toast.makeText(c, "Ilova topilmadi: $name", Toast.LENGTH_LONG).show(); Speaker.say("Topolmadim") }; return false }
        try {
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            Speaker.say(hit.loadLabel(pm).toString() + " ni ochayapman")
            return true
        } catch (e: Exception) { Toast.makeText(c, "Ochilmadi: ${e.message}", Toast.LENGTH_LONG).show(); Speaker.say("Ocha olmadim"); return false }
    }
}
