package com.xoqon.app

import android.service.notification.NotificationListenerService

// Bildirishnomalarga ruxsat berilganda ishga tushadi: "yangi xabarni och" uchun kerak
class NotifService : NotificationListenerService() {
    companion object { @Volatile var inst: NotifService? = null }
    override fun onListenerConnected() { inst = this }
    override fun onListenerDisconnected() { if (inst === this) inst = null }
}
