package com.xoqon.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import androidx.core.content.ContextCompat

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val l = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
        l.addView(TextView(this).apply { text = "Jarvis yordamchi"; textSize = 24f })
        val key = EditText(this).apply { hint = "AI kaliti: Claude, ChatGPT yoki Gemini (ixtiyoriy)"; setText(getSharedPreferences("x", MODE_PRIVATE).getString("apikey", "")) }
        l.addView(key)
        val status = TextView(this).apply { textSize = 14f }
        l.addView(status)
        val wakeField = EditText(this).apply { hint = "Qo'shimcha chaqiruv so'zlari (vergul bilan)"; setText(getSharedPreferences("x", MODE_PRIVATE).getString("wake", "")) }
        l.addView(wakeField)
        val fastBox = CheckBox(this).apply {
            text = "Tezkor rejim: aniq buyruqlar darhol, AI faqat tushunmaganda"
            isChecked = getSharedPreferences("x", MODE_PRIVATE).getBoolean("fast", true)
            setOnCheckedChangeListener { _, v -> getSharedPreferences("x", MODE_PRIVATE).edit().putBoolean("fast", v).apply() }
        }
        l.addView(fastBox)
        val boyBox = CheckBox(this).apply {
            text = "Yigit ovozi (qalinroq)"
            isChecked = getSharedPreferences("x", MODE_PRIVATE).getBoolean("boy", true)
            setOnCheckedChangeListener { _, v -> getSharedPreferences("x", MODE_PRIVATE).edit().putBoolean("boy", v).apply() }
        }
        l.addView(boyBox)
        Speaker.init(this)
        l.addView(btn("Ovozni almashtirish (sinab ko'ring)") { Speaker.nextVoice(this) })
        val saved = getSharedPreferences("x", MODE_PRIVATE).getString("apikey", "") ?: ""
        status.text = if (saved.isEmpty()) "Kalit kiritilmagan: eski usulda ishlaydi" else "Kalit saqlangan: " + saved.take(3) + "…" + saved.takeLast(4)
        fun check() {
            val k = key.text.toString().trim()
            getSharedPreferences("x", MODE_PRIVATE).edit().putString("apikey", k).putString("wake", wakeField.text.toString()).apply()
            if (k.isEmpty()) { status.text = "Kalit kiritilmagan: eski usulda ishlaydi"; return }
            status.text = "Tekshirilmoqda…"
            Brain.test(k) { msg -> runOnUiThread { status.text = msg } }
        }
        l.addView(btn("1. Ruxsatlar (mikrofon, bildirishnoma)") {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.SEND_SMS, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE), 1)
        })
        l.addView(btn("2. Boshqa ilovalar ustida ko'rsatish") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        l.addView(btn("3. Batareya cheklovini o'chirish") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        l.addView(btn("4. Ishga tushirish") {
            check()
            ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))
        })
        l.addView(btn("5. Xabarlarni ochish ruxsati (bildirishnoma)") { startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) })
        l.addView(btn("Kalitni tekshirish") { check() })
        l.addView(btn("To'xtatish") { stopService(Intent(this, WakeService::class.java)) })
        setContentView(l)
    }
}
