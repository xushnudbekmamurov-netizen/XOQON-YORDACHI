1) https://alphacephei.com/vosk/models saytidan "vosk-model-small-uz" (o'zbek, ~50 MB) ni yuklab oling va zip'ni oching.
2) Ichidagi papkaning ICHIDAGI fayllarni (am, conf, graph, ivector ...) app/src/main/assets/model-uz/ ichiga ko'chiring.
   (u yerdagi "uuid" faylni o'chirmang.)
3) Android Studio'da Xoqon papkasini oching -> Build > Build APK(s).
4) Telefonga o'rnating, ilovada 1-4 tugmalarni ketma-ket bosing.
Buyruqlar: "Xoqon" ... "soat 7:30 ga budilnik qo'y", "Telegram och".
Eshitilgan matn ekranda ko'rinadi; "Xoqon"ni boshqacha eshitsa, ilovadagi "Qo'shimcha chaqiruv so'zlari" maydoniga yoki WakeService.kt dagi wake ro'yxatiga qo'shing.

x21 (versiya 1.1) da nima o'zgardi:
- Tezlik: ilovalar ro'yxati har buyruqda emas, orqa oqimda o'qiladi va 5 daqiqa saqlanadi (ilova qotmaydi).
- Tezlik: AI kutish vaqti qisqartirildi (matn 8 s, ovoz 15 s). Boshqa modelga faqat model topilmasa (404), limit tugasa (429) yoki band bo'lsa (503) o'tiladi.
- Tezlik: "Ha, janob" deb gapirish sukut bo'yicha o'chirilgan, buyruq signaldan keyin darhol yoziladi (ilovada yoqish mumkin). Jimlik 0.5 soniyada gap tugagan deb hisoblanadi.
- Chaqiruv: "Xoqon, budilnik 7 ga" bir nafasda aytilsa ham buyruq to'liq olinadi (avval qirqilib qolardi).
- Chaqiruv: "yolg'on", "qo'qon" kabi oddiy so'zlar endi faqat gap boshida va keyin buyruq kelsagina uyg'otadi.
- Xavfsizlik: SMS va qo'ng'iroqdan oldin "Akmal ga xabar yuboraymi?" deb so'raladi, javob: "ha" yoki "yo'q" (ilovada o'chirib qo'yish mumkin).
- Kontakt: kontaktlar ro'yxati endi AI'ga yuborilmaydi; AI faqat ismni yozadi, telefon o'zi qidiradi (kirill/lotin va yaqin yozilishlarni ham topadi).
- AI javobi tekshiriladi: soat/daqiqa chegaralanadi, soat berilmasa budilnik qo'yilmaydi (avval 00:00 ga qo'yilib ketardi).
- SMS ruxsati berilmagan bo'lsa, tayyor matn bilan SMS ilovasi ochiladi.
- AndroidManifest: allowBackup o'chirildi (AI kaliti Google zaxira nusxasiga tushmaydi), ilova nomi "Xoqon" bo'ldi, kalit maydoni yashirildi.

Maxfiylik: murakkab buyruqlarda ovoz yozuvi va o'rnatilgan ilovalar nomlari tanlangan AI xizmatiga (Gemini/Claude/ChatGPT) yuboriladi. Kontaktlar yuborilmaydi. Oddiy buyruqlar oflayn ishlaydi.

Google Play haqida: SEND_SMS va CALL_PHONE ruxsatlari Google Play'da qattiq cheklangan (deklaratsiya kerak, rad etilishi mumkin).
