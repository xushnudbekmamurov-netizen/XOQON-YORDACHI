package com.xoqon.app

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.ContactsContract.CommonDataKinds.Phone as PhoneKind
import android.util.Base64
import android.widget.Toast
import org.vosk.Model
import org.vosk.Recognizer
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Brain {
    private const val CLAUDE = "claude-haiku-5-5"
    private const val GEMINI = "gemini-3.5-flash"
    private const val OPENAI = "gpt-4o-mini"
    private val main = Handler(Looper.getMainLooper())

    fun key(c: Context): String = c.getSharedPreferences("x", Context.MODE_PRIVATE).getString("apikey", "")?.trim() ?: ""
    fun enabled(c: Context) = key(c).isNotEmpty()

    // Kalitni tekshirish: kichik so'rov yuboradi va natijani matn qilib qaytaradi
    fun test(key: String, cb: (String) -> Unit) {
        val kind = when {
            key.startsWith("sk-ant-") -> "Claude"
            key.startsWith("AQ.") || key.startsWith("AIza") -> "Gemini"
            key.startsWith("sk-") -> "ChatGPT"
            else -> ""
        }
        if (kind.isEmpty()) { cb("✗ Kalit turi tanilmadi. Claude: sk-ant-, ChatGPT: sk-, Gemini: AQ. yoki AIza bilan boshlanadi"); return }
        Thread {
            val msg = try {
                val j = ask(key, "salom", listOf())
                "✓ " + kind + " kaliti ishlayapti. Javob: " + j.toString().take(80)
            } catch (e: Exception) { "✗ " + kind + " xatosi: " + (e.message ?: "noma'lum") }
            cb(msg)
        }.start()
    }

    fun isGemini(c: Context): Boolean = key(c).let { it.startsWith("AQ.") || it.startsWith("AIza") }

    @Volatile private var ctxContacts: List<String> = emptyList()

    private fun contactNames(c: Context): List<String> {
        return try {
            val out = LinkedHashSet<String>()
            c.contentResolver.query(PhoneKind.CONTENT_URI, arrayOf(PhoneKind.DISPLAY_NAME), null, null, PhoneKind.DISPLAY_NAME + " ASC")?.use {
                while (it.moveToNext() && out.size < 150) { val n = it.getString(0); if (n != null) out.add(n) }
            }
            out.toList()
        } catch (e: Exception) { emptyList() }
    }

    fun fast(c: Context): Boolean = c.getSharedPreferences("x", Context.MODE_PRIVATE).getBoolean("fast", true)

    // Ovoz yozuvi: avval Vosk matni oddiy qoidalar bilan sinab ko'riladi (tez), bo'lmasa Gemini'ga yuboriladi
    fun handleAudio(c: Context, pcm: ByteArray, model: Model?) {
        val k = key(c)
        val labels = appLabels(c)
        ctxContacts = contactNames(c)
        Thread {
            var fallback = ""
            try {
                if (model != null) {
                    val r = Recognizer(model, 16000f)
                    r.acceptWaveForm(pcm, pcm.size)
                    fallback = Commands.norm(JSONObject(r.finalResult).optString("text"))
                    r.close()
                }
            } catch (e: Exception) {}
            main.post {
                if (fast(c) && fallback.isNotBlank() && Commands.run(c, fallback, true)) return@post
                Thread {
                    val t0 = System.currentTimeMillis()
                    try {
                        val j = askAudio(k, Rec.wav(pcm), labels, fallback)
                        main.post { dispatch(c, j, System.currentTimeMillis() - t0) }
                    } catch (e: Exception) {
                        main.post {
                            Toast.makeText(c, "AI ovoz xatosi: " + e.message, Toast.LENGTH_LONG).show()
                            if (fallback.isNotBlank()) handle(c, fallback) else Speaker.say("Tushunmadim")
                        }
                    }
                }.start()
            }
        }.start()
    }

    private fun askAudio(key: String, wav: ByteArray, labels: List<String>, hint: String): JSONObject {
        val parts = JSONArray()
            .put(JSONObject().put("text", "The user's spoken command (Uzbek) is in this audio. Understand it and answer with the JSON action. Rough offline transcript (often wrong, only a hint): " + hint))
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "audio/wav").put("data", Base64.encodeToString(wav, Base64.NO_WRAP))))
        val out = generate(key, system(labels), parts, 30000)
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }

    fun handle(c: Context, text: String) {
        val k = key(c)
        if (k.isEmpty()) { Commands.run(c, text); return }
        if (fast(c) && Commands.run(c, text, true)) return
        ctxContacts = contactNames(c)
        val labels = appLabels(c)
        Thread {
            try {
                val json = ask(k, text, labels)
                main.post { dispatch(c, json) }
            } catch (e: Exception) {
                main.post {
                    Toast.makeText(c, "AI xatosi: " + e.message, Toast.LENGTH_LONG).show()
                    Commands.run(c, text)
                }
            }
        }.start()
    }

    private fun appLabels(c: Context): List<String> {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { it.loadLabel(pm).toString() }.distinct().take(250)
    }

    private fun system(labels: List<String>): String =
        "You are Jarvis, a voice assistant on an Android phone. The user speaks Uzbek; speech recognition output is noisy " +
        "(Latin or Cyrillic letters, wrong spellings, foreign app names written phonetically, e.g. 'pabji', 'pabg', 'pubji', 'babji' all mean PUBG MOBILE). " +
        "Common mishearings: 'shavarlar' or 'habarlar' means xabarlar (Messages app). Infer what the user meant and answer with ONE JSON object only, no other text. Allowed forms: " +
        "{\"action\":\"open_app\",\"app\":\"<exact label from the installed list>\"} ; " +
        "{\"action\":\"alarm\",\"hour\":0-23,\"minute\":0-59} ; " +
        "{\"action\":\"sms\",\"contact\":\"<contact name in Latin, e.g. onam>\",\"text\":\"<message to send>\"} ; " +
        "{\"action\":\"music\",\"cmd\":\"play|pause|next|prev\"} ; " +
        "{\"action\":\"youtube\",\"query\":\"<search>\"} ; " +
        "{\"action\":\"call\",\"contact\":\"<exact contact name from the contacts list>\"} ; " +
        "{\"action\":\"find_contact\",\"contact\":\"<exact contact name>\"} ; " +
        "{\"action\":\"new_message\",\"mode\":\"open|read\"} for opening or reading the newest incoming message notification ; " +
        "{\"action\":\"system\",\"cmd\":\"wifi|bluetooth|home|flashlight_on|flashlight_off|battery|volume_up|volume_down\"} for phone controls (home = leave the current app / go to home screen) ; " +
        "{\"action\":\"answer\",\"text\":\"<clear, fluent, grammatically correct Uzbek in Latin script, 2-4 short sentences, no foreign accent, no Russian or Turkish words>\"} for factual questions (population of a country, facts about the Pacific Ocean, science, history); use the word taxminan for numbers that may be outdated ; " +
        "{\"action\":\"chat\",\"text\":\"<one short Uzbek sentence in plain words, no emojis, no symbols>\"} for questions or small talk ; " +
        "{\"action\":\"unknown\"} if unclear. " +
        "For open_app the app value must be copied exactly from this installed list: " + labels.joinToString("; ") +
        ". For sms, call and find_contact the contact value must be copied exactly from this contacts list (relatives: onam/volidam = mother, dadam/otam = father): " + ctxContacts.joinToString("; ")

    // Kalit turini boshlanishidan aniqlaydi: sk-ant- (Claude), AIza (Gemini), sk- (ChatGPT)
    private fun ask(key: String, text: String, labels: List<String>): JSONObject {
        val sys = system(labels)
        val out: String = when {
            key.startsWith("sk-ant-") -> {
                val body = JSONObject().put("model", CLAUDE).put("max_tokens", 300).put("system", sys)
                    .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", text)))
                val r = post("https://api.anthropic.com/v1/messages", mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"), body)
                JSONObject(r).getJSONArray("content").getJSONObject(0).getString("text")
            }
            key.startsWith("AQ.") || key.startsWith("AIza") -> gemini(key, sys, text)
            key.startsWith("sk-") -> {
                val body = JSONObject().put("model", OPENAI).put("max_tokens", 300).put("response_format", JSONObject().put("type", "json_object"))
                    .put("messages", JSONArray().put(JSONObject().put("role", "system").put("content", sys))
                        .put(JSONObject().put("role", "user").put("content", text)))
                val r = post("https://api.openai.com/v1/chat/completions", mapOf("Authorization" to "Bearer " + key), body)
                JSONObject(r).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
            }
            else -> throw Exception("Kalit turi tanilmadi (sk-ant-, sk-, AQ., AIza)")
        }
        return JSONObject(out.substring(out.indexOf('{'), out.lastIndexOf('}') + 1))
    }

    // Gemini modellari tez-tez almashadi: bir nechta nomni ketma-ket sinaymiz va xatolarni ko'rsatamiz
    @Volatile var goodModel: String? = null
    @Volatile var lastModel = ""
    private val MODELS = listOf("gemini-flash-lite-latest", "gemini-flash-latest", "gemini-3.5-flash")

    private fun generate(key: String, sys: String, parts: JSONArray, readMs: Int): String {
        val errs = StringBuilder()
        for (m in (listOfNotNull(goodModel) + MODELS.filter { it != goodModel })) {
            try {
                val body = JSONObject()
                    .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
                    .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
                    .put("generationConfig", JSONObject().put("maxOutputTokens", 500).put("responseMimeType", "application/json"))
                val r = post("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent", mapOf("x-goog-api-key" to key), body, readMs)
                val ps = JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
                var text = ""
                for (i in 0 until ps.length()) { val t = ps.getJSONObject(i).optString("text"); if (t.isNotEmpty()) text = t }
                if (text.isEmpty()) throw Exception("bo'sh javob")
                goodModel = m; lastModel = m
                return text
            } catch (e: Exception) { errs.append(m).append(": ").append((e.message ?: "").take(90)).append(" | ") }
        }
        throw Exception(errs.toString())
    }

    private fun gemini(key: String, sys: String, text: String): String {
        val errs = StringBuilder()
        try {
            return generate(key, sys, JSONArray().put(JSONObject().put("text", text)), 20000)
        } catch (e: Exception) { errs.append(e.message) }
        try {
            val body = JSONObject().put("model", GEMINI).put("input", sys + "\n\nUser said (transcript): " + text)
            val r = post("https://generativelanguage.googleapis.com/v1beta/interactions", mapOf("x-goog-api-key" to key), body, 30000)
            return geminiText(JSONObject(r))
        } catch (e: Exception) { errs.append(" || interactions: ").append(e.message) }
        throw Exception(errs.toString())
    }

    // Interactions API javobining ikkala shaklini o'qiydi (outputs yoki steps)
    private fun geminiText(j: JSONObject): String {
        val direct = j.optString("output_text")
        if (direct.isNotEmpty()) return direct
        val outs = j.optJSONArray("outputs")
        if (outs != null) for (i in outs.length() - 1 downTo 0) {
            val t = outs.optJSONObject(i)?.optString("text") ?: ""
            if (t.isNotEmpty()) return t
        }
        val steps = j.optJSONArray("steps")
        if (steps != null) for (i in steps.length() - 1 downTo 0) {
            val content = steps.optJSONObject(i)?.optJSONArray("content") ?: continue
            for (k in 0 until content.length()) {
                val t = content.optJSONObject(k)?.optString("text") ?: ""
                if (t.isNotEmpty()) return t
            }
        }
        throw Exception("Gemini javobi tushunarsiz: " + j.toString().take(120))
    }

    fun post(url: String, headers: Map<String, String>, body: JSONObject, readMs: Int = 20000): String {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = 8000; conn.readTimeout = readMs; conn.doOutput = true
        conn.setRequestProperty("content-type", "application/json")
        for ((k, v) in headers) conn.setRequestProperty(k, v)
        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
        val code = conn.responseCode
        val st = if (code in 200..299) conn.inputStream else conn.errorStream
        val resp = st?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) throw Exception("HTTP " + code + " " + resp.take(150))
        return resp
    }

    private fun dispatch(c: Context, a: JSONObject, ms: Long = -1) {
        val tm = if (ms >= 0) " " + (ms / 100) / 10.0 + "s" else ""
        Toast.makeText(c, "Jarvis" + tm + " [" + lastModel + "]: " + a.toString().take(120), Toast.LENGTH_SHORT).show()
        when (a.optString("action")) {
            "open_app" -> openLabel(c, a.optString("app"))
            "alarm" -> Commands.run(c, "budilnik " + a.optInt("hour") + ":" + a.optInt("minute").toString().padStart(2, '0'))
            "sms" -> Sms.sendTo(c, a.optString("contact"), a.optString("text"))
            "music" -> Music.tryHandle(c, when (a.optString("cmd")) { "pause" -> "to'xtat"; "next" -> "keyingi"; "prev" -> "oldingi"; else -> "musiqa qo'y" })
            "call" -> Calls.call(c, a.optString("contact"))
            "find_contact" -> Calls.find(c, a.optString("contact"))
            "new_message" -> if (a.optString("mode") == "read") Calls.readLatest(c) else Calls.openLatest(c)
            "system" -> Sys.run(c, a.optString("cmd"))
            "youtube" -> if (!Music.tryHandle(c, "youtube " + a.optString("query"))) Speaker.say("Tushunmadim")
            "chat", "answer" -> {
                val s = a.optString("text")
                if (s.isNotBlank()) { Toast.makeText(c, s, Toast.LENGTH_LONG).show(); Speaker.say(s) }
            }
            else -> Speaker.say("Tushunmadim")
        }
    }

    private fun openLabel(c: Context, label: String) {
        val pm = c.packageManager
        val l = label.lowercase()
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
        val hit = apps.firstOrNull { it.loadLabel(pm).toString().lowercase() == l }
            ?: apps.firstOrNull { l.isNotEmpty() && it.loadLabel(pm).toString().lowercase().contains(l) }
        if (hit == null) { Speaker.say("Topolmadim"); return }
        try {
            val i = pm.getLaunchIntentForPackage(hit.activityInfo.packageName)!!
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            c.startActivity(i)
            Speaker.say(hit.loadLabel(pm).toString() + " ni ochayapman")
        } catch (e: Exception) { Speaker.say("Ocha olmadim") }
    }
}
