package com.xoqon.app

import android.Manifest
import android.app.ActivityOptions
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Phone as PhoneKind
import android.service.notification.StatusBarNotification
import android.widget.Toast

object Calls {
    class Hit(val name: String, val number: String, val uri: Uri?)

    fun tryHandle(c: Context, t: String): Boolean {
        val words = t.split(" ").filter { it.isNotBlank() }
        if (t.contains("xabar") && (t.contains("yangi") || t.contains("keldi") || t.contains("oxirgi"))) {
            if (t.contains("o'qi") || t.contains("oqi") || t.contains("eshittir")) readLatest(c) else openLatest(c)
            return true
        }
        val ci = words.indexOfFirst { it.startsWith("telefon") || it.startsWith("qo'ng'iroq") || it.startsWith("qongiroq") || it.startsWith("zvonok") }
        if (ci > 0) { call(c, words.subList(0, ci).joinToString(" ")); return true }
        val ti = words.indexOfFirst { it == "top" || it.startsWith("topib") }
        if (ti > 0 && !t.contains("youtube")) { find(c, words.subList(0, ti).joinToString(" ")); return true }
        return false
    }

    private fun names(raw: String): List<String> {
        val w = Commands.norm(raw).trim().split(" ").first()
        val out = ArrayList<String>()
        if (w.length > 3 && (w.endsWith("ga") || w.endsWith("ka") || w.endsWith("qa") || w.endsWith("ni"))) out.add(w.dropLast(2))
        out.add(w)
        return out
    }

    // Kirill -> lotin (ismlarni taqqoslash uchun)
    private val cyr = mapOf(
        'а' to "a", 'б' to "b", 'в' to "v", 'г' to "g", 'д' to "d", 'е' to "e", 'ё' to "yo", 'ж' to "j", 'з' to "z",
        'и' to "i", 'й' to "y", 'к' to "k", 'л' to "l", 'м' to "m", 'н' to "n", 'о' to "o", 'п' to "p", 'р' to "r",
        'с' to "s", 'т' to "t", 'у' to "u", 'ф' to "f", 'х' to "x", 'ц' to "s", 'ч' to "ch", 'ш' to "sh", 'ъ' to "",
        'ы' to "i", 'ь' to "", 'э' to "e", 'ю' to "yu", 'я' to "ya", 'ў' to "o", 'қ' to "k", 'ғ' to "g", 'ҳ' to "x"
    )

    // Ismni soddalashtiradi: kichik harf, kirill -> lotin, h->x, q->k, w->v, belgilarsiz
    fun simple(s: String): String {
        val sb = StringBuilder()
        for (ch in Commands.norm(s)) {
            val m = cyr[ch]
            if (m != null) sb.append(m) else if (ch.isLetter()) sb.append(ch)
        }
        return sb.toString().replace('h', 'x').replace('q', 'k').replace('w', 'v')
    }

    // Ikki so'z orasidagi farq (Levenshtein masofasi)
    private fun dist(a: String, b: String): Int {
        val dp = IntArray(b.length + 1) { it }
        for (i in 1..a.length) {
            var prev = dp[0]
            dp[0] = i
            for (j in 1..b.length) {
                val tmp = dp[j]
                dp[j] = minOf(dp[j] + 1, dp[j - 1] + 1, prev + (if (a[i - 1] == b[j - 1]) 0 else 1))
                prev = tmp
            }
        }
        return dp[b.length]
    }

    // Aniq topilmasa: AI ismni biroz boshqacha yozgan bo'lishi mumkin (Akmal / Aqmal / Акмал), eng yaqinini topamiz
    private fun fuzzy(c: Context, raw: String): Hit? {
        val want = simple(raw)
        if (want.length < 3) return null
        var best: Hit? = null
        var bestD = 99
        try {
            c.contentResolver.query(
                PhoneKind.CONTENT_URI,
                arrayOf(PhoneKind.DISPLAY_NAME, PhoneKind.NUMBER, PhoneKind.CONTACT_ID, PhoneKind.LOOKUP_KEY),
                null, null, null
            )?.use {
                var n = 0
                while (it.moveToNext() && n < 3000) {
                    n++
                    val name = it.getString(0) ?: continue
                    val parts = listOf(simple(name)) + name.split(" ").map { w -> simple(w) }
                    for (p in parts) {
                        if (p.length < 2) continue
                        val d = dist(want, p)
                        if (d < bestD) {
                            bestD = d
                            best = Hit(name, it.getString(1) ?: "", ContactsContract.Contacts.getLookupUri(it.getLong(2), it.getString(3)))
                        }
                    }
                }
            }
        } catch (e: Exception) { return null }
        val limit = if (want.length <= 4) 1 else 2
        return if (bestD <= limit) best else null
    }

    fun lookup(c: Context, raw: String): Hit? {
        val toks = ArrayList<String>()
        toks.add(Commands.norm(raw).trim())
        for (n in names(raw)) toks.addAll(Sms.alias[n] ?: listOf(n))
        for (tok in toks.distinct()) {
            if (tok.length < 2) continue
            for (v in listOf(tok, tok.replaceFirstChar { it.uppercase() }).distinct()) {
                try {
                    var first: Hit? = null
                    c.contentResolver.query(
                        PhoneKind.CONTENT_URI,
                        arrayOf(PhoneKind.DISPLAY_NAME, PhoneKind.NUMBER, PhoneKind.CONTACT_ID, PhoneKind.LOOKUP_KEY),
                        PhoneKind.DISPLAY_NAME + " LIKE ?", arrayOf("%" + v + "%"), null
                    )?.use {
                        var n = 0
                        while (it.moveToNext() && n < 30) {
                            n++
                            val h = Hit(it.getString(0) ?: "", it.getString(1) ?: "",
                                ContactsContract.Contacts.getLookupUri(it.getLong(2), it.getString(3)))
                            // Ismi aynan mos kelgan kontakt birinchi o'rinda, aks holda topilgan birinchisi
                            if (simple(h.name) == simple(tok)) return h
                            if (first == null) first = h
                        }
                    }
                    if (first != null) return first
                } catch (e: Exception) { return null }
            }
        }
        return fuzzy(c, raw)
    }

    // Qo'ng'iroqdan oldin tasdiq so'raladi ("Akmal ga qo'ng'iroq qilaymi?")
    fun call(c: Context, name: String) {
        val h = lookup(c, name)
        if (h == null) { Toast.makeText(c, "Kontakt topilmadi: " + name, Toast.LENGTH_LONG).show(); Speaker.say("Kontakt topilmadi"); return }
        Confirm.ask(c, h.name + " ga qo'ng'iroq qilaymi?") { dial(c, h) }
    }

    private fun dial(c: Context, h: Hit) {
        Speaker.say(h.name + " ga qo'ng'iroq qilyapman")
        val granted = c.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        try {
            c.startActivity(Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(h.number)))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { Toast.makeText(c, "Qo'ng'iroq xatosi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    fun find(c: Context, name: String) {
        val h = lookup(c, name)
        if (h == null) { Toast.makeText(c, "Kontakt topilmadi: " + name, Toast.LENGTH_LONG).show(); Speaker.say("Topolmadim"); return }
        Toast.makeText(c, h.name + ": " + h.number, Toast.LENGTH_LONG).show()
        Speaker.say(h.name + ", raqami " + h.number.filter { it.isDigit() }.toList().joinToString(" "))
        try {
            if (h.uri != null) c.startActivity(Intent(Intent.ACTION_VIEW, h.uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) { }
    }

    private fun pick(c: Context): StatusBarNotification? {
        val svc = NotifService.inst ?: return null
        return try {
            val list = svc.activeNotifications.filter { !it.isOngoing && it.packageName != c.packageName && it.notification.contentIntent != null }
            val msgs = list.filter { it.notification.category == Notification.CATEGORY_MESSAGE }
            (if (msgs.isNotEmpty()) msgs else list).maxByOrNull { it.postTime }
        } catch (e: Exception) { null }
    }

    private fun title(n: StatusBarNotification): String = n.notification.extras.getString(Notification.EXTRA_TITLE) ?: n.packageName

    private fun missing(): String = if (NotifService.inst == null) "Bildirishnomalarga ruxsat bering" else "Yangi xabar topilmadi"

    fun openLatest(c: Context) {
        val n = pick(c)
        if (n == null) { Speaker.say(missing()); return }
        try {
            val o = ActivityOptions.makeBasic()
            if (Build.VERSION.SDK_INT >= 34) o.setPendingIntentBackgroundActivityStartMode(1) // 1 = fondan ochishga ruxsat
            n.notification.contentIntent.send(c, 0, null, null, null, null, o.toBundle())
            Speaker.say(title(n) + " xabarini ochdim")
        } catch (e: Exception) { Toast.makeText(c, "Xabar ochilmadi: " + e.message, Toast.LENGTH_LONG).show() }
    }

    fun readLatest(c: Context) {
        val n = pick(c)
        if (n == null) { Speaker.say(missing()); return }
        val text = n.notification.extras.getCharSequence(Notification.EXTRA_TEXT)?.toString() ?: ""
        Toast.makeText(c, title(n) + ": " + text, Toast.LENGTH_LONG).show()
        Speaker.say(title(n) + ". " + text)
    }
}
