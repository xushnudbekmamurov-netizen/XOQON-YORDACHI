package com.xoqon.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

// Gemini TTS: tabiiy o'zbekcha ovoz (Northern Uzbek). Takrorlanadigan gaplar keshda saqlanadi.
object CloudTts {
    private val MODELS = listOf("gemini-3.8-flash-lite-tts", "gemini-3.8-flash-tts")
    private val main = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null

    private fun voice(c: Context) = c.getSharedPreferences("x", Context.MODE_PRIVATE).getString("gvoice", "Puck") ?: "Puck"

    private fun file(c: Context, text: String): File {
        val dir = File(c.cacheDir, "tts"); dir.mkdirs()
        return File(dir, Integer.toHexString((voice(c) + "|" + text).hashCode()) + ".wav")
    }

    // Kalit bo'lsa true qaytaradi va o'zi gapiradi; xato bo'lsa oddiy ovozga o'tadi
    fun speak(c: Context, text: String, onDone: (() -> Unit)?): Boolean {
        if (!Brain.isGemini(c)) return false
        val key = Brain.key(c)
        Thread {
            var f: File? = null
            try {
                val x = file(c, text)
                if (!x.exists() || x.length() < 100) fetch(key, text, voice(c), x)
                f = x
            } catch (e: Exception) {
                main.post { Toast.makeText(c, "Ovoz xatosi: " + (e.message ?: "").take(120), Toast.LENGTH_LONG).show() }
            }
            main.post { if (f != null) play(c, f, text, onDone) else Speaker.sayLocal(text, onDone) }
        }.start()
        return true
    }

    // Tez-tez aytiladigan gaplarni oldindan tayyorlaydi
    fun warm(c: Context, phrases: List<String>) {
        if (!Brain.isGemini(c)) return
        val key = Brain.key(c)
        Thread {
            for (p in phrases) {
                try { val x = file(c, p); if (!x.exists() || x.length() < 100) fetch(key, p, voice(c), x) } catch (e: Exception) { }
            }
        }.start()
    }

    private fun fetch(key: String, text: String, voice: String, out: File) {
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        var err = ""
        for (m in MODELS) {
            try {
                val r = Brain.post("https://generativelanguage.googleapis.com/v1beta/models/" + m + ":generateContent", mapOf("x-goog-api-key" to key), body, 40000)
                val part = JSONObject(r).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData")
                val bytes = Base64.decode(part.getString("data"), Base64.DEFAULT)
                val mime = part.optString("mimeType").lowercase()
                out.writeBytes(if (mime.contains("l16") || mime.contains("pcm")) Rec.wav(bytes, 24000) else bytes)
                return
            } catch (e: Exception) { err += m + ": " + (e.message ?: "").take(80) + " | " }
        }
        throw Exception(err)
    }

    private fun play(c: Context, f: File, text: String, onDone: (() -> Unit)?) {
        try {
            player?.release()
            val mp = MediaPlayer()
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener {
                it.release(); if (player === it) player = null
                Focus.scheduleGive(c, 2500)
                if (onDone != null) onDone()
            }
            mp.setOnErrorListener { m, _, _ -> m.release(); f.delete(); Speaker.sayLocal(text, onDone); true }
            mp.prepare()
            mp.start()
            player = mp
        } catch (e: Exception) { f.delete(); Speaker.sayLocal(text, onDone) }
    }
}
