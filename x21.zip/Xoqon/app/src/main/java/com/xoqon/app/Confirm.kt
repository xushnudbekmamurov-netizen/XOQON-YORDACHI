package com.xoqon.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.widget.Toast

// SMS va qo'ng'iroqdan oldin ovoz bilan tasdiq so'raydi. Javob: "ha" yoki "yo'q".
// Savol aytib bo'lingandan keyingina javob qabul qilinadi (o'z ovozimizni eshitib, o'zimiz tasdiqlab yubormaslik uchun).
object Confirm {
    private val main = Handler(Looper.getMainLooper())
    private val yes = setOf("ha", "xa", "hop", "xop", "xo'p", "mayli", "tasdiq", "tasdiqlayman", "albatta", "yubor", "yuboring", "qil", "qiling", "ok", "okey")
    private val no = setOf("yo'q", "yoq", "yo'qa", "bekor", "kerakmas", "to'xta", "to'xtat", "qilma", "yuborma", "yubormang", "stop")

    @Volatile private var action: (() -> Unit)? = null
    @Volatile private var armed = false
    @Volatile private var gen = 0

    // Sozlamada o'chirilgan bo'lsa, tasdiqsiz darhol bajariladi
    fun enabled(c: Context): Boolean = c.getSharedPreferences("x", Context.MODE_PRIVATE).getBoolean("confirm", true)

    // Javob kutilyaptimi (savol aytib bo'lingan va vaqt tugamagan)
    fun waiting(): Boolean = action != null && armed

    fun ask(c: Context, question: String, onYes: () -> Unit) {
        if (!enabled(c)) { onYes(); return }
        gen++
        val g = gen
        action = onYes
        armed = false
        Toast.makeText(c, question + " (ha / yo'q)", Toast.LENGTH_LONG).show()
        Speaker.say(question) { arm(g) }
    }

    private fun arm(g: Int) {
        main.postDelayed({
            if (g == gen && action != null) {
                armed = true
                // 12 soniyada javob bo'lmasa bekor qilinadi
                main.postDelayed({
                    if (g == gen && action != null) { cancel(); Speaker.say("Bekor qilindi") }
                }, 12000)
            }
        }, 500)
    }

    private fun cancel() { action = null; armed = false; gen++ }

    // true qaytarsa, matn javob sifatida ishlatilgan
    fun answer(t: String): Boolean {
        val a = action ?: return false
        if (!armed) return false
        val words = t.split(" ").filter { it.isNotBlank() }
        if (words.isEmpty() || words.size > 3) return false
        if (words.any { it in no }) { cancel(); Speaker.say("Bekor qilindi"); return true }
        if (words.any { it in yes }) { cancel(); main.post { a() }; return true }
        return false
    }
}
