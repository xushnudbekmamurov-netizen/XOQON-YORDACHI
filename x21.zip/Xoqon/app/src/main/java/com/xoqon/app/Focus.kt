package com.xoqon.app

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper

// Buyruq paytida musiqani to'xtatib turadi (audio fokus), keyin qaytaradi
object Focus {
    private var req: AudioFocusRequest? = null
    private val main = Handler(Looper.getMainLooper())
    private val pending = Runnable { }

    fun take(c: Context) {
        try {
            main.removeCallbacksAndMessages(null)
            val am = c.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            give(c)
            val r = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANT).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener { _ -> }
                .build()
            am.requestAudioFocus(r)
            req = r
        } catch (e: Exception) { }
    }

    fun give(c: Context) {
        try {
            val r = req
            if (r != null) (c.getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(r)
        } catch (e: Exception) { }
        req = null
    }

    fun scheduleGive(c: Context, ms: Long) {
        main.removeCallbacksAndMessages(null)
        main.postDelayed({ give(c) }, ms)
    }
}
