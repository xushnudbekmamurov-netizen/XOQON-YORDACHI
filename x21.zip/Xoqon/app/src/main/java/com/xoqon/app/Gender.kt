package com.xoqon.app

// Ovoz balandligidan (F0) erkak yoki ayol ovozini taxminan aniqlaydi.
object Gender {
    fun detect(s: ShortArray): String? {
        val sr = Rec.SR
        val frame = 1024
        val hop = 512
        if (s.size < frame * 3) return null
        val starts = ArrayList<Int>()
        val rms = ArrayList<Double>()
        var i = 0
        while (i + frame <= s.size) {
            var sum = 0.0
            for (k in 0 until frame) sum += s[i + k].toDouble() * s[i + k]
            rms.add(Math.sqrt(sum / frame)); starts.add(i)
            i += hop
        }
        val maxR = rms.maxOrNull() ?: return null
        if (maxR < 500) return null
        val minLag = sr / 320
        val maxLag = sr / 70
        val f0 = ArrayList<Double>()
        for (idx in starts.indices) {
            if (rms[idx] < maxR * 0.5) continue
            val st = starts[idx]
            var r0 = 0.0
            for (k in 0 until frame) r0 += s[st + k].toDouble() * s[st + k]
            if (r0 <= 0.0) continue
            var best = 0.0
            var bestLag = 0
            for (lag in minLag..maxLag) {
                var r = 0.0
                for (k in 0 until frame - lag) r += s[st + k].toDouble() * s[st + k + lag]
                val nr = r / r0
                if (nr > best) { best = nr; bestLag = lag }
            }
            if (best > 0.45 && bestLag > 0) f0.add(sr.toDouble() / bestLag)
        }
        if (f0.size < 2) return null
        f0.sort()
        val med = f0[f0.size / 2]
        return if (med < 165.0) "male" else "female"
    }
}
