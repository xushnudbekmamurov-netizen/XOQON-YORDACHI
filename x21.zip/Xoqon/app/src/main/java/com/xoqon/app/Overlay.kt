package com.xoqon.app

import android.content.Context
import android.graphics.PixelFormat
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager

// 1x1 ko'rinmas oyna: Android fondagi ilovaga boshqa ilovani ochishga ruxsat beradi
object Overlay {
    private var view: View? = null

    fun show(c: Context) {
        if (view != null || !Settings.canDrawOverlays(c)) return
        try {
            val wm = c.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val v = View(c)
            val lp = WindowManager.LayoutParams(
                1, 1, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            )
            lp.gravity = Gravity.TOP or Gravity.START
            wm.addView(v, lp)
            view = v
        } catch (e: Exception) { view = null }
    }

    fun hide(c: Context) {
        try {
            val v = view
            if (v != null) (c.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(v)
        } catch (e: Exception) { }
        view = null
    }
}
