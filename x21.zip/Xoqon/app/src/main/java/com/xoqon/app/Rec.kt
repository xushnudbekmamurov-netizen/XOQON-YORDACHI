package com.xoqon.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

object Rec {
    const val SR = 16000

    // Gap tugaguncha (eng ko'pi bilan 7 soniya) yozadi. Gap bo'lmasa null qaytaradi.
    fun record(maxMs: Int = 7000): ByteArray? {
        val min = AudioRecord.getMinBufferSize(SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val ar = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 3200) * 2)
        try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(ar.audioSessionId)?.setEnabled(true) } catch (e: Exception) { }
        try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(ar.audioSessionId)?.setEnabled(true) } catch (e: Exception) { }
        val out = ByteArrayOutputStream()
        val buf = ShortArray(1600)
        var spoke = false
        var quiet = 0
        var elapsed = 0
        try {
            ar.startRecording()
            while (elapsed < maxMs) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) break
                var sum = 0.0
                for (i in 0 until n) sum += buf[i] * buf[i].toDouble()
                val rms = Math.sqrt(sum / n)
                val bb = ByteArray(n * 2)
                for (i in 0 until n) {
                    bb[i * 2] = (buf[i].toInt() and 0xFF).toByte()
                    bb[i * 2 + 1] = (buf[i].toInt() shr 8).toByte()
                }
                out.write(bb)
                val ms = n * 1000 / SR
                elapsed += ms
                if (rms > 700) { spoke = true; quiet = 0 }
                else if (spoke) { quiet += ms; if (quiet > 700) break }
                else if (elapsed > 4000) break
            }
        } finally {
            try { ar.stop() } catch (e: Exception) {}
            ar.release()
        }
        return if (spoke) out.toByteArray() else null
    }

    fun wav(pcm: ByteArray, sr: Int = SR): ByteArray {
        val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        h.put("RIFF".toByteArray()); h.putInt(36 + pcm.size); h.put("WAVE".toByteArray())
        h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(1)
        h.putInt(sr); h.putInt(sr * 2); h.putShort(2); h.putShort(16)
        h.put("data".toByteArray()); h.putInt(pcm.size)
        return h.array() + pcm
    }
}
