package com.xoqon.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.media.ToneGenerator
import android.net.Uri
import android.os.Build
import android.telephony.SmsManager
import android.widget.Toast

object Sms {
    val alias = mapOf(
        "onam" to listOf("onam", "ona", "oyi", "mama", "онам", "она"),
        "dadam" to listOf("dadam", "ota", "dada", "papa", "дадам", "ота"),
        "akam" to listOf("akam", "aka", "ака"),
        "opam" to listOf("opam", "opa", "singlim", "опа"),
        "volidam" to listOf("volidam", "volida", "onam", "ona", "oyi", "mama", "онам", "она"),
        "otam" to listOf("otam", "ota", "dadam", "dada", "papa", "дадам", "ота")
    )

    fun tryHandle(c: Context, t: String): Boolean {
        if (!t.contains(" deb ")) return false
        val left = t.substringBefore(" deb ").trim()
        val right = t.substringAfter(" deb ")
        val isSms = listOf("xabar", "habar", "sms").any { right.contains(it) } && listOf("yoz", "yubor").any { right.contains(it) }
        if (!isSms) return false
        val words = left.split(" ").filter { it.isNotBlank() }
        if (words.size < 2) { toast(c, "Xabar matni aytilmadi"); tone(false); Speaker.say("Xabar matnini aytmadingiz"); return true }
        val w = words[0]
        val names = (if (w.length > 3 && (w.endsWith("ga") || w.endsWith("ka") || w.endsWith("qa"))) listOf(w.dropLast(2), w) else listOf(w))
        val body = words.drop(1).joinToString(" ").take(500).replaceFirstChar { it.uppercase() }
        var hit: Calls.Hit? = null
        for (n in names) { hit = Calls.lookup(c, n); if (hit != null) break }
        if (hit == null) { toast(c, "Kontakt topilmadi: ${names[0]}"); tone(false); Speaker.say("Kontakt topilmadi"); return true }
        deliver(c, hit, body)
        return true
    }

    fun sendTo(c: Context, contact: String, text: String) {
        val n = Commands.norm(contact).trim()
        val body = text.trim().take(500).replaceFirstChar { it.uppercase() }
        if (n.isEmpty() || body.isEmpty()) { toast(c, "Kontakt yoki matn yo'q"); tone(false); Speaker.say("Xabarni tushunmadim"); return }
        val hit = Calls.lookup(c, n) ?: Calls.lookup(c, n.split(" ").first())
        if (hit == null) { toast(c, "Kontakt topilmadi: " + n); tone(false); Speaker.say("Kontakt topilmadi"); return }
        deliver(c, hit, body)
    }

    // Yuborishdan oldin kimga ketayotgani aytiladi va tasdiq so'raladi (noto'g'ri odamga ketib qolmasligi uchun)
    private fun deliver(c: Context, h: Calls.Hit, body: String) {
        toast(c, h.name + ": " + body)
        Confirm.ask(c, h.name + " ga xabar yuboraymi?") { send(c, h, body) }
    }

    private fun send(c: Context, h: Calls.Hit, body: String) {
        // SMS yuborish ruxsati berilmagan bo'lsa, tayyor matn bilan SMS ilovasi ochiladi
        if (c.checkSelfPermission(Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) { compose(c, h, body); return }
        try {
            val m = mgr(c)
            m.sendMultipartTextMessage(h.number, null, m.divideMessage(body), null, null)
            tone(true)
            toast(c, "Yuborildi (" + h.number + "): " + body); Speaker.say("Xabar yuborildi")
        } catch (e: Exception) {
            tone(false)
            toast(c, "SMS xatosi: " + e.message); Speaker.say("Xabar yuborilmadi")
        }
    }

    private fun compose(c: Context, h: Calls.Hit, body: String) {
        try {
            c.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + Uri.encode(h.number)))
                .putExtra("sms_body", body).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            Speaker.say("Xabar tayyor, yuborish tugmasini bosing")
        } catch (e: Exception) {
            tone(false)
            toast(c, "SMS ilovasi ochilmadi: " + e.message); Speaker.say("Xabar yuborilmadi")
        }
    }

    @Suppress("DEPRECATION")
    private fun mgr(c: Context): SmsManager =
        if (Build.VERSION.SDK_INT >= 31) c.getSystemService(SmsManager::class.java) else SmsManager.getDefault()

    private fun tone(ok: Boolean) {
        ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(if (ok) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_NACK)
    }

    private fun toast(c: Context, s: String) = Toast.makeText(c, s, Toast.LENGTH_LONG).show()
}
