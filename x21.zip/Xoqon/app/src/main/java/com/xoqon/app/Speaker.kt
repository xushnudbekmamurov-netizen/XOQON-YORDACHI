package com.xoqon.app

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.widget.Toast
import java.util.Locale

object Speaker {
    private var tts: TextToSpeech? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile var ready = false
    @Volatile var lang = ""
    private var app: Context? = null

    fun init(c: Context) {
        if (tts != null) return
        val ctx = c.applicationContext
        val locales = listOf(Locale("uz", "UZ"), Locale("uz"), Locale("tr", "TR"), Locale("ru", "RU"))
        tts = TextToSpeech(ctx) { st ->
            if (st == TextToSpeech.SUCCESS) {
                for (loc in locales) {
                    if (ready) break
                    val r = tts?.setLanguage(loc) ?: -2
                    if (r >= TextToSpeech.LANG_AVAILABLE) {
                        ready = true
                        lang = loc.language
                        app = ctx
                        applyVoice()
                        main.post { Toast.makeText(ctx, "Ovoz tili: " + loc.language, Toast.LENGTH_LONG).show() }
                    }
                }
            }
        }
    }

    fun say(text: String, onDone: (() -> Unit)? = null) {
        val t = tts
        if (!ready || t == null) { if (onDone != null) main.post { onDone() }; return }
        var done = false
        fun once() { if (!done) { done = true; if (onDone != null) onDone() } }
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { main.post { once() } }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { main.post { once() } }
        })
        t.setPitch(if (app?.getSharedPreferences("x", Context.MODE_PRIVATE)?.getBoolean("boy", true) != false) 0.7f else 1.1f)
        t.speak(if (lang == "tr") turkish(text) else text, TextToSpeech.QUEUE_FLUSH, null, "u" + System.nanoTime())
        if (onDone != null) main.postDelayed({ once() }, 4000)
    }

    private fun voicesFor(): List<Voice> = try {
        tts?.voices?.filter { it.locale.language == lang }?.sortedWith(compareBy({ it.isNetworkConnectionRequired }, { it.name })) ?: emptyList()
    } catch (e: Exception) { emptyList() }

    private fun applyVoice() {
        val vs = voicesFor()
        val p = app?.getSharedPreferences("x", Context.MODE_PRIVATE) ?: return
        if (vs.isNotEmpty()) try { tts?.voice = vs[p.getInt("voiceIdx", 0) % vs.size] } catch (e: Exception) { }
    }

    // Tugma bosilganda keyingi ovozga o'tadi va namuna aytadi
    fun nextVoice(c: Context) {
        val vs = voicesFor()
        val p = (app ?: c.applicationContext).getSharedPreferences("x", Context.MODE_PRIVATE)
        if (!ready || vs.isEmpty()) { Toast.makeText(c, "Ovoz hali tayyor emas, qayta bosing", Toast.LENGTH_SHORT).show(); return }
        val idx = (p.getInt("voiceIdx", 0) + 1) % vs.size
        p.edit().putInt("voiceIdx", idx).apply()
        applyVoice()
        Toast.makeText(c, "Ovoz " + (idx + 1) + "/" + vs.size + ": " + vs[idx].name, Toast.LENGTH_LONG).show()
        say("Ha, janob")
    }

    // O'zbek lotin yozuvini turkcha talaffuzga yaqinlashtiradi (j=c, x=h, q=k, sh=ş, ch=ç ...)
    private fun turkish(s: String): String {
        var t = s.lowercase()
        for (q in listOf("'", "ʻ", "’", "‘", "`")) { t = t.replace("o" + q, "o").replace("g" + q, "g") }
        t = t.replace("sh", "ş").replace("ch", "ç")
        t = t.replace(Regex("['ʻ’‘`]"), "")
        return t.replace('j', 'c').replace('x', 'h').replace('q', 'k').replace('w', 'v')
    }

    fun shutdown() { tts?.shutdown(); tts = null; ready = false }
}
