package com.xoqon.app

import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.audiofx.AcousticEchoCanceler
import android.media.audiofx.NoiseSuppressor
import android.os.Handler
import android.os.Looper
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener

// Vosk uchun o'z mikrofon sikli: exo bostirish (AEC) va shovqin kamaytirish yoqilgan,
// shuning uchun musiqa ichidan ovozni ajratib olish osonroq. Oxirgi 2 soniya ovoz saqlanadi.
class VoskMic(private val model: Model, private val listener: RecognitionListener) {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var running = false
    private val ring = ShortArray(Rec.SR * 2)
    @Volatile private var pos = 0
    @Volatile private var filled = 0

    fun start(timeoutMs: Int = 0) {
        running = true
        Thread { loop(timeoutMs) }.start()
    }

    fun stop() { running = false }
    fun shutdown() { }

    fun recent(): ShortArray {
        val n = filled
        val out = ShortArray(n)
        val start = (pos - n + ring.size) % ring.size
        for (i in 0 until n) out[i] = ring[(start + i) % ring.size]
        return out
    }

    private fun push(b: ShortArray, n: Int) {
        for (i in 0 until n) { ring[pos] = b[i]; pos = (pos + 1) % ring.size }
        filled = minOf(ring.size, filled + n)
    }

    private fun loop(timeoutMs: Int) {
        var ar: AudioRecord? = null
        var rec: Recognizer? = null
        try {
            val min = AudioRecord.getMinBufferSize(Rec.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            ar = AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, Rec.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, maxOf(min, 8000) * 2)
            val sid = ar.audioSessionId
            try { if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sid)?.setEnabled(true) } catch (e: Exception) { }
            try { if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sid)?.setEnabled(true) } catch (e: Exception) { }
            rec = Recognizer(model, 16000f)
            ar.startRecording()
            val buf = ShortArray(2000)
            val t0 = System.currentTimeMillis()
            while (running) {
                val n = ar.read(buf, 0, buf.size)
                if (n <= 0) break
                push(buf, n)
                if (rec.acceptWaveForm(buf, n)) {
                    val r = rec.result
                    main.post { if (running) listener.onResult(r) }
                } else {
                    val p = rec.partialResult
                    main.post { if (running) listener.onPartialResult(p) }
                }
                if (timeoutMs > 0 && System.currentTimeMillis() - t0 > timeoutMs) {
                    running = false
                    main.post { listener.onTimeout() }
                    break
                }
            }
            val fin = rec.finalResult
            main.post { listener.onFinalResult(fin) }
        } catch (e: Exception) {
            main.post { listener.onError(e) }
        } finally {
            try { ar?.stop() } catch (e: Exception) { }
            ar?.release()
            rec?.close()
        }
    }
}
