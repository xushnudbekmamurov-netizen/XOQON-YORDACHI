package com.xoqon.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.*
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.SpeechService
import org.vosk.android.StorageService
import android.speech.RecognitionListener as GoogleListener
import org.vosk.android.RecognitionListener as VoskListener

class WakeService : Service() {
    // Vosk "Xoqon" so'zini shu variantlar bilan taniydi. Noto'g'ri eshitsa, shu ro'yxatga qo'shing.
    private val wake = listOf("xoqon", "hoqon", "xaqon", "xoqan", "xokon", "hokon", "khokon", "хоқон", "хокон", "хакон", "хоган", "хаккон")
    private var model: Model? = null
    private var vosk: VoskMic? = null
    private var rec: SpeechRecognizer? = null
    private var busy = false
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("x", "Xoqon", NotificationManager.IMPORTANCE_LOW))
        val n = NotificationCompat.Builder(this, "x").setContentTitle("Jarvis tinglayapti")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now).build()
        ServiceCompat.startForeground(this, 1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        Speaker.init(this)
        CloudTts.warm(this, listOf("Ha, janob", "Labbay, honim"))
        StorageService.unpack(this, "model-uz", "model",
            { m -> model = m; startWake() },
            { e -> Toast.makeText(this, "Model xatosi: ${e.message}", Toast.LENGTH_LONG).show() })
    }

    private fun startWake() {
        busy = false
        try {
            vosk = VoskMic(model!!, listener).also { it.start() }
        } catch (e: Exception) {
            Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private val listener = object : VoskListener {
        override fun onPartialResult(h: String?) = check(h, "partial")
        override fun onResult(h: String?) = check(h, "text")
        override fun onFinalResult(h: String?) {}
        override fun onError(e: Exception?) {}
        override fun onTimeout() {}
    }

    private fun check(json: String?, key: String) {
        if (busy || json == null) return
        val t = Commands.norm(JSONObject(json).optString(key))
        if (t.isBlank()) return
        val w = (wake + Commands.extraWake + custom()).firstOrNull { it.isNotBlank() && t.contains(it) }
            ?: Regex("[jyzcdgx]h?[aeo]r[vwb][iey]").find(t)?.value
        if (w == null) {
            if (key == "text") Toast.makeText(this, "Eshitdi: $t", Toast.LENGTH_SHORT).show()
            return
        }
        busy = true
        val rest = t.substringAfter(w).trim()
        val recent = vosk?.recent()
        Thread {
            val g = if (recent != null) Gender.detect(recent) else null
            main.post { onWake(rest, g) }
        }.start()
    }

    private fun onWake(rest: String, gender: String?) {
        grab()
        Focus.take(this)
        Toast.makeText(this, "Ovoz: " + (if (gender == "male") "erkak" else if (gender == "female") "ayol" else "noaniq"), Toast.LENGTH_SHORT).show()
        vosk?.stop(); vosk?.shutdown(); vosk = null
        if (rest.length > 3 && (key(rest) || Brain.enabled(this))) { beep(); Brain.handle(this, rest); startWake(); return }
        greet(gender) { if (Brain.isGemini(this)) listenAudio() else listenVosk() }
    }

    private val hideRunnable = Runnable { Overlay.hide(this); Focus.give(this) }

    // Buyruq davomida: CPU uxlab qolmasin (wakelock) va fondan ilova ochishga ruxsat bo'lsin (ko'rinmas oyna)
    private fun grab() {
        try {
            (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "xoqon:cmd").acquire(30000)
        } catch (e: Exception) { }
        Overlay.show(this)
        main.removeCallbacks(hideRunnable)
        main.postDelayed(hideRunnable, 25000)
    }

    private fun beep() { ToneGenerator(AudioManager.STREAM_MUSIC, 80).startTone(ToneGenerator.TONE_PROP_BEEP) }

    // "Ha, janob" deydi; ovoz bo'lmasa signal beradi. Gapirib bo'lgach buyruqni tinglaydi.
    private fun greet(gender: String?, then: () -> Unit) {
        val phrase = if (gender == "female") "Labbay, honim" else "Ha, janob"
        if (!Speaker.ready && !Brain.isGemini(this)) { beep(); then(); return }
        Speaker.say(phrase) { then() }
    }

    private fun listen() {
        rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec?.setRecognitionListener(object : GoogleListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) { Toast.makeText(this@WakeService, t, Toast.LENGTH_SHORT).show(); Brain.handle(this@WakeService, t) }
                resume()
            }
            override fun onError(e: Int) = resume()
            override fun onReadyForSpeech(p: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        rec?.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "uz-UZ")
        })
    }

    // Buyruqni ham Vosk bilan tinglaymiz: Google tanuvchisi fonda mikrofonsiz qoladi.
    private var gotCmd = false

    private fun listenVosk() {
        gotCmd = false
        try {
            vosk = VoskMic(model!!, cmdListener).also { it.start(7000) }
        } catch (e: Exception) {
            Toast.makeText(this, "Xato: ${e.message}", Toast.LENGTH_LONG).show()
            startWake()
        }
    }

    private val cmdListener = object : VoskListener {
        override fun onPartialResult(h: String?) {}
        override fun onResult(h: String?) = got(h)
        override fun onFinalResult(h: String?) = got(h)
        override fun onError(e: Exception?) { main.post { startWake() } }
        override fun onTimeout() { main.post { vosk?.stop(); vosk?.shutdown(); vosk = null; startWake() } }
    }

    private fun got(json: String?) {
        if (json == null || gotCmd) return
        val t = Commands.norm(JSONObject(json).optString("text"))
        if (t.isBlank()) return
        gotCmd = true
        main.post {
            vosk?.stop(); vosk?.shutdown(); vosk = null
            Toast.makeText(this, "Buyruq: $t", Toast.LENGTH_SHORT).show()
            Brain.handle(this, t)
            startWake()
        }
    }

    // Gemini kaliti bo'lsa: buyruqni yozib olib, ovozning o'zini Gemini'ga yuboramiz
    private fun listenAudio() {
        Thread {
            val pcm = try { Rec.record() } catch (e: Exception) { null }
            main.post {
                if (pcm != null) Brain.handleAudio(this, pcm, model)
                startWake()
            }
        }.start()
    }

    // Foydalanuvchi ilovada vergul bilan yozgan qo'shimcha chaqiruv so'zlari
    private fun custom(): List<String> =
        (getSharedPreferences("x", MODE_PRIVATE).getString("wake", "") ?: "").split(",").map { Commands.norm(it).trim() }.filter { it.isNotBlank() }

    private fun key(s: String) = Commands.isCommand(s)

    private fun resume() { rec?.destroy(); rec = null; startWake() }

    override fun onDestroy() {
        vosk?.stop(); vosk?.shutdown(); rec?.destroy(); Speaker.shutdown(); model?.close(); super.onDestroy()
    }
}
